package principal;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.LinkedList;


/**
 * Servlet implementation class AdicionarCarrinho
 */
@WebServlet("/AdicionarCarrinho")
public class AdicionarCarrinho extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdicionarCarrinho() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ProdutoDAO pDAO=new ProdutoDAO();
		
		Produto p1;
		Produto pCarrinho=new Produto();
		boolean achou=false;
		int id=Integer.parseInt(request.getParameter("id"));
		
		p1=pDAO.BuscarPorId(id);
		
		pCarrinho.setId(p1.getId());
		pCarrinho.setNome(p1.getNome());
		pCarrinho.setPreco(p1.getPreco());
		
		HttpSession session = request.getSession();
		
		Object listaCarinhoObj = session.getAttribute("listaCarrinho");
		
		if (listaCarinhoObj == null){
			
			LinkedList<Produto> listaCarrinho = new LinkedList<Produto>();
			
			pCarrinho.setQuantidade(1);
			
			listaCarrinho.add(pCarrinho);
			
			session.setAttribute("listaCarrinho",listaCarrinho);
			
		} else {
			
			LinkedList<Produto> listaCarrinho = (LinkedList)listaCarinhoObj;
			
			for(int i=0;i<listaCarrinho.size();i++) {
				
				if(p1.getId()==listaCarrinho.get(i).getId()) {
			
					int qtd = listaCarrinho.get(i).getQuantidade();
					System.out.println(qtd);
					qtd++;
					listaCarrinho.get(i).setQuantidade(qtd);
					achou=true;
				
				}
			}
			
			if(!achou) {
				listaCarrinho.add(pCarrinho);
			}
			
			
			request.setAttribute("listaCarrinho", listaCarrinho);
			
		}
		
		RequestDispatcher view = request.getRequestDispatcher("carrinho.jsp");
		
		view.forward(request, response);	

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
