package principal;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EfetuarAlteracaoServlet
 */
@WebServlet("/EfetuarAlteracaoServlet")
public class EfetuarAlteracaoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EfetuarAlteracaoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		Object listaCarinhoObj = session.getAttribute("listaCarrinho");
		
		int i=0;
		String nome = request.getParameter("nome");
		double preco = Double.valueOf(request.getParameter("preco"));
		int quantidade = Integer.valueOf(request.getParameter("quantidade"));
		int id=Integer.valueOf(request.getParameter("id"));
		
		Produto p1=new Produto();
		
		p1.setNome(nome);
		p1.setPreco(preco);
		p1.setQuantidade(quantidade);
		p1.setId(id);
		
		LinkedList<Produto> listaCarrinho = (LinkedList)listaCarinhoObj;
		
		if(listaCarrinho!=null) {	
			
			for(i=0;i<listaCarrinho.size();i++) {
				if(id==listaCarrinho.get(i).getId()) {
					listaCarrinho.get(i).setNome(nome);
					listaCarrinho.get(i).setPreco(preco);
				}
			}
			
		}
		
		ProdutoDAO pDAO=new ProdutoDAO();
		
		pDAO.alterar(p1);
		
		RequestDispatcher view = 
				request.getRequestDispatcher("ResultadoAlterar.jsp");
		
		view.forward(request, response);
	}

}
